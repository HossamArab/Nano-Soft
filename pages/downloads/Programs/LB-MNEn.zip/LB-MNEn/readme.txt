*** Installation ***

    * On Windows 98/ME/2000/XP/2003 or Windows NT 4.0:  select Run 
      from the Taskbar Start menu, type the full name of the
      file (for example, A:SETUP.EXE), press the Enter key, and 
      follow the prompts.

***SYSTEM REQUIREMENTS*** 

 - x86-based personal computer (Pentium minimum;Pentium II,Pentium III
   Pentium IV recommended)
 - Microsoft Windows 98/ME/2000/XP/2003, Microsoft Windows NT 4.0
 - 128 MB application RAM
 - 32 MB hard disk space

***Contacting The Author***

    If you need any additional information to complete your
    software, please call us at the numbers below. We would
    be happy to answer any questions you have regarding our
    products or services.

    * PHONE NUMBERS * 
      China    (0592)5710087

    * FAX NUMBERS * 
      China    (0592)5710029

    * ELECTRONIC ACCESS * 
      Internet E-mail: osa@aclas.com 
      World Wide Web: http://www.aclas.com